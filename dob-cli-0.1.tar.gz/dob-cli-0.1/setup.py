
from setuptools import setup, find_packages

# Helper function to load dependencies from requirements.txt
def load_requirements(filename):
    with open(filename, 'r') as f:
        return f.read().splitlines()

setup(
    name='dob-cli',
    version='0.1',
    description='DevOps Bot Cli: The DOB CLI for remote command execution with persona-based authentication.',
    author='Dee Empire GmBH',
    author_email='deeempiregmbh@gmail.com',
    url='https://github.com/Devops-Bot-Official',
    packages=find_packages(),
    install_requires=load_requirements('requirements.txt'),
    entry_points='''
        [console_scripts]
        dob=dob.cli:cli
    ''',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
