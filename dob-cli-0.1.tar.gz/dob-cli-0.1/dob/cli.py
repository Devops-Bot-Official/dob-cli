import click
import json
import os
import requests
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization

CONFIG_FILE_PATH = os.path.expanduser("~/.dobconfig.json")


def load_config():
    """Load the persona config file."""
    if not os.path.exists(CONFIG_FILE_PATH):
        click.echo(click.style(f"Error: Config file not found at {CONFIG_FILE_PATH}. Please run 'persona config' first.", fg="red"))
        return None

    with open(CONFIG_FILE_PATH, "r") as config_file:
        return json.load(config_file)


def sign_token(private_key_path, token):
    """Sign the token using the private key."""
    with open(private_key_path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(key_file.read(), password=None)

    signature = private_key.sign(
        token.encode(),
        padding.PKCS1v15(),
        hashes.SHA256()
    )

    return signature.hex()


@click.group()
def cli():
    """`persona` CLI for remote command execution and configuration."""


@cli.command(context_settings=dict(
    ignore_unknown_options=True,
    allow_extra_args=True
))
@click.pass_context
def run(ctx):
    """
    Proxy any `dob` command to the host for execution.
    """
    config = load_config()
    if not config:
        return

    persona_name = config["persona_name"]
    token = config["token"]
    private_key_path = config["private_key_path"]
    host_endpoint = config["host_endpoint"]

    # Check if '--file-path' is present in the arguments
    args = list(ctx.args)
    file_content = None
    if '--file-path' in args:
        file_index = args.index('--file-path') + 1
        if file_index < len(args):
            file_path = args[file_index]
            if os.path.exists(file_path):
                with open(file_path, 'r') as file:
                    file_content = file.read()
                args[file_index] = "<inline_file>"
            else:
                click.echo(click.style(f"Error: File '{file_path}' not found.", fg="red"))
                return
        else:
            click.echo(click.style("Error: '--file-path' option requires a file path.", fg="red"))
            return

    # Sign the token
    signature = sign_token(private_key_path, token)

    # Prepare headers for the request
    headers = {
        "Persona-Name": persona_name,
        "Authorization": token,
        "Signature": signature
    }

    # Convert the command arguments into a single command string
    command_string = "dob " + " ".join(args)

    click.echo(click.style(f"Forwarding command to host: {command_string}", fg="cyan"))

    # Send the request to the host
    response = requests.post(
        f"{host_endpoint}/execute",
        json={"command": command_string, "file_content": file_content},
        headers=headers
    )

    if response.status_code == 200:
        click.echo(response.text)
    else:
        click.echo(click.style(f"Execution failed with status {response.status_code}: {response.text}", fg="red"))


@cli.command()
@click.option("--persona-name", required=True, help="Name of the persona.")
@click.option("--token", required=True, help="Token associated with the persona.")
@click.option("--private-key-path", required=True, type=click.Path(exists=True), help="Path to the private key PEM file.")
@click.option("--host-endpoint", required=True, help="Host endpoint URL (e.g., http://<public_ip>:<port>).")
def config(persona_name, token, private_key_path, host_endpoint):
    """
    Configure the remote execution by generating a `.dobconfig.json` file.
    """
    config_data = {
        "persona_name": persona_name,
        "token": token,
        "private_key_path": private_key_path,
        "host_endpoint": host_endpoint
    }

    # Write configuration to the file
    with open(CONFIG_FILE_PATH, "w") as config_file:
        json.dump(config_data, config_file, indent=4)

    click.echo(click.style(f"Configuration saved to {CONFIG_FILE_PATH}.", fg="green"))


if __name__ == "__main__":
    cli()
